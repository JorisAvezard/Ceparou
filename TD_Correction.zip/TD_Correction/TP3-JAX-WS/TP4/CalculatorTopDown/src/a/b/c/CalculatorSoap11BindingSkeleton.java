/**
 * CalculatorSoap11BindingSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package a.b.c;

public class CalculatorSoap11BindingSkeleton implements a.b.c.CalculatorPortType, org.apache.axis.wsdl.Skeleton {
    private a.b.c.CalculatorPortType impl;
    private static java.util.Map _myOperations = new java.util.Hashtable();
    private static java.util.Collection _myOperationsList = new java.util.ArrayList();

    /**
    * Returns List of OperationDesc objects with this name
    */
    public static java.util.List getOperationDescByName(java.lang.String methodName) {
        return (java.util.List)_myOperations.get(methodName);
    }

    /**
    * Returns Collection of OperationDescs
    */
    public static java.util.Collection getOperationDescs() {
        return _myOperationsList;
    }

    static {
        org.apache.axis.description.OperationDesc _oper;
        org.apache.axis.description.FaultDesc _fault;
        org.apache.axis.description.ParameterDesc [] _params;
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://c.b.a", "n1"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), java.lang.Integer.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://c.b.a", "n2"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), java.lang.Integer.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("add", _params, new javax.xml.namespace.QName("http://c.b.a", "return"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://c.b.a", "add"));
        _oper.setSoapAction("urn:add");
        _myOperationsList.add(_oper);
        if (_myOperations.get("add") == null) {
            _myOperations.put("add", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("add")).add(_oper);
        _params = new org.apache.axis.description.ParameterDesc [] {
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://c.b.a", "a"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false), 
            new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://c.b.a", "b"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"), int.class, false, false), 
        };
        _oper = new org.apache.axis.description.OperationDesc("computeMinusOf", _params, new javax.xml.namespace.QName("http://c.b.a", "computeMinusOfReturn"));
        _oper.setReturnType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        _oper.setElementQName(new javax.xml.namespace.QName("http://c.b.a", "computeMinusOf"));
        _oper.setSoapAction("urn:computeMinusOf");
        _myOperationsList.add(_oper);
        if (_myOperations.get("computeMinusOf") == null) {
            _myOperations.put("computeMinusOf", new java.util.ArrayList());
        }
        ((java.util.List)_myOperations.get("computeMinusOf")).add(_oper);
    }

    public CalculatorSoap11BindingSkeleton() {
        this.impl = new a.b.c.CalculatorSoap11BindingImpl();
    }

    public CalculatorSoap11BindingSkeleton(a.b.c.CalculatorPortType impl) {
        this.impl = impl;
    }
    public java.lang.Integer add(java.lang.Integer n1, java.lang.Integer n2) throws java.rmi.RemoteException
    {
        java.lang.Integer ret = impl.add(n1, n2);
        return ret;
    }

    public int computeMinusOf(int a, int b) throws java.rmi.RemoteException
    {
        int ret = impl.computeMinusOf(a, b);
        return ret;
    }

}
