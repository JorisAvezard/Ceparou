package temp;

public class ConverterTempProxy implements temp.ConverterTemp {
  private String _endpoint = null;
  private temp.ConverterTemp converterTemp = null;
  
  public ConverterTempProxy() {
    _initConverterTempProxy();
  }
  
  public ConverterTempProxy(String endpoint) {
    _endpoint = endpoint;
    _initConverterTempProxy();
  }
  
  private void _initConverterTempProxy() {
    try {
      converterTemp = (new temp.ConverterTempServiceLocator()).getConverterTemp();
      if (converterTemp != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)converterTemp)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)converterTemp)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (converterTemp != null)
      ((javax.xml.rpc.Stub)converterTemp)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public temp.ConverterTemp getConverterTemp() {
    if (converterTemp == null)
      _initConverterTempProxy();
    return converterTemp;
  }
  
  public double kelvinToCelsius(double temp) throws java.rmi.RemoteException{
    if (converterTemp == null)
      _initConverterTempProxy();
    return converterTemp.kelvinToCelsius(temp);
  }
  
  public double celsiusToKelvin(double temp) throws java.rmi.RemoteException{
    if (converterTemp == null)
      _initConverterTempProxy();
    return converterTemp.celsiusToKelvin(temp);
  }
  
  public double celsiusToFahrenheit(double temp) throws java.rmi.RemoteException{
    if (converterTemp == null)
      _initConverterTempProxy();
    return converterTemp.celsiusToFahrenheit(temp);
  }
  
  public double fahrenheitToCelsius(double temp) throws java.rmi.RemoteException{
    if (converterTemp == null)
      _initConverterTempProxy();
    return converterTemp.fahrenheitToCelsius(temp);
  }
  
  
}