/**
 * ConverterTempServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package temp;

public class ConverterTempServiceLocator extends org.apache.axis.client.Service implements temp.ConverterTempService {

    public ConverterTempServiceLocator() {
    }


    public ConverterTempServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public ConverterTempServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for ConverterTemp
    private java.lang.String ConverterTemp_address = "http://localhost:8080/TempConverter/services/ConverterTemp";

    public java.lang.String getConverterTempAddress() {
        return ConverterTemp_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String ConverterTempWSDDServiceName = "ConverterTemp";

    public java.lang.String getConverterTempWSDDServiceName() {
        return ConverterTempWSDDServiceName;
    }

    public void setConverterTempWSDDServiceName(java.lang.String name) {
        ConverterTempWSDDServiceName = name;
    }

    public temp.ConverterTemp getConverterTemp() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(ConverterTemp_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getConverterTemp(endpoint);
    }

    public temp.ConverterTemp getConverterTemp(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            temp.ConverterTempSoapBindingStub _stub = new temp.ConverterTempSoapBindingStub(portAddress, this);
            _stub.setPortName(getConverterTempWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setConverterTempEndpointAddress(java.lang.String address) {
        ConverterTemp_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (temp.ConverterTemp.class.isAssignableFrom(serviceEndpointInterface)) {
                temp.ConverterTempSoapBindingStub _stub = new temp.ConverterTempSoapBindingStub(new java.net.URL(ConverterTemp_address), this);
                _stub.setPortName(getConverterTempWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("ConverterTemp".equals(inputPortName)) {
            return getConverterTemp();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://temp", "ConverterTempService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://temp", "ConverterTemp"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("ConverterTemp".equals(portName)) {
            setConverterTempEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
