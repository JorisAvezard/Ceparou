package temp;

public class ConverterTemp {

	
	public double celsiusToKelvin( double temp)
	{
		return temp +273.15;
	}
	
	public double kelvinToCelsius ( double temp)
	{
		return temp - 273.15;
	}
	
	public double celsiusToFahrenheit ( double temp)
	{
		return (temp * 1.8 + 32);
	}
	
	public double fahrenheitToCelsius ( double temp)
	{
		return (temp - 32) / 1.8;
	}
	
	
}
