package calc;

public class Calculator {

	public int computeSumOf( int a, int b)
	{
		return a+b;
	}

	public int computeDivOf( int a, int b)
	{
		return a/b;
	}
	
	public int computeMinusOf( int a, int b)
	{
		return a-b;
	}
	
	public int computeMultiplication(int a, int b){
		return a*b;
	}
	
	public int computeSquare(int a){
		return a*a;
	}
	
	public int computePow(int a, int b){
		return (int)Math.pow(a, b);
	}

}

