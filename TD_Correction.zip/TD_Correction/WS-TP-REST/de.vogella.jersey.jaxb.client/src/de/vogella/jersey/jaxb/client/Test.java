package de.vogella.jersey.jaxb.client;

import java.net.URI;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;

import org.glassfish.jersey.client.ClientConfig;

public class Test {
  public static void main(String[] args) {
	  
	//code for second (jax-rs) service
    System.out.println("start rest w/o");
    ClientConfig config2 = new ClientConfig();
    Client client2 = ClientBuilder.newClient(config2);
    WebTarget target2 = client2.target(UriBuilder.fromUri("http://localhost:8080/com.vogella.jersey.first"));
    System.out.println(target2.path("rest").path("hello").request().accept(MediaType.TEXT_PLAIN).get(String.class));
    //*************** string for storing the output of SERVICE 2 ***************
    String jaxws_result = target2.path("rest").path("hello").request().accept(MediaType.TEXT_PLAIN).get(String.class);
    System.out.println("end rest w/o");
    //end of code for second (jax-rs) service
    
    ClientConfig config = new ClientConfig();
    Client client = ClientBuilder.newClient(config);
    WebTarget target = client.target(getBaseURI());

	//code for first (jax-rs with annotations) service
    System.out.println("start rest jaxb");
    // Get XML
    System.out.println(target.path("rest").path("todo").path("Super Service Dev").request().accept(MediaType.TEXT_XML).get(String.class));
    System.out.println(target.path("rest").path("todo")
    		.path(jaxws_result).request()
    		.accept(MediaType.TEXT_XML).get(String.class));
    // Get XML for application
    //System.out.println(target.path("rest").path("todo").request().accept(MediaType.APPLICATION_JSON).get(String.class));
    //System.out.println(target.path("rest").path("todo").request().accept("application/json").get(String.class));
    // Get JSON for application
    //System.out.println(target.path("rest").path("todo").path("Super Service Dev 2").request().accept(MediaType.APPLICATION_XML).get(String.class));
    System.out.println(target.path("rest").path("todo")
    		.path("query").queryParam("from", "ME")
    		.queryParam("to", "YOU").request().accept(MediaType.APPLICATION_XML).get(String.class));
    System.out.println("end rest jaxb");
	//end of code for first (jax-rs with annotations) service
    
  }

  private static URI getBaseURI() {
    return UriBuilder.fromUri("http://localhost:8080/com.vogella.jersey.jaxb/").build();
  }

} 
